// TODO: declare an array of numbers 1 through 10.

const numArray = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

let elementAtIndexFive = numArray[5];

//open the browser console to check results
console.log('The array element with index 5 is: ', elementAtIndexFive);

